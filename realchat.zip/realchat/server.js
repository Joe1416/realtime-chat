const express = require("express")
const mysql = require("mysql")
const BodyParser = require("body-parser");
const { Socket } = require("socket.io");
const app = express();

const http = require("http")
const server = http.createServer(app)
const {Server} = require ("socket.io")
const io = new Server(server)

app.use(BodyParser.urlencoded({ extended: true }))

app.set("view engine", "ejs")
app.set("views", "views")

const db = mysql.createConnection({
    host:"localhost",
    database:"realchat",
    user:"root",
    password:"",
})

db.connect((err) => {
    if (err) throw err
    console.log("database connected...")

        // Get data
        app.get("/", (req, res) => {
        const sql = "SELECT * FROM chat"
        db.query(sql, (err, result) => {
        const chats = JSON.parse(JSON.stringify(result))
        res.render("index", {chats: chats, title: "Realtime Chatting User" })
        })
    })

            // Tambah user
            app.post("/tambah", (req, res) => {
            const insertSql = `INSERT INTO chat (nama, prodi) VALUES ('${req.body.nama}
            ', '${req.body.prodi}');`
            db.query(insertSql, (err, result) => {
                if (err) throw err
                res.redirect("/")
            })
        })
    })

    app.get("/chat", (req, res) => {
        res.render("chat", { 
            loginTitle: "Realtime Chatting Room", 
            RealtimeChatting: "Realtime Chatting",
    })
    })

io.on("connection", (socket) => {
    socket.on("message", (data) => {
        const {id, message} = data
        // logika broadcast chat 2
        socket.broadcast.emit("message", id, message)
    })
})

server.listen(8000, () => {
    console.log("server ready...")
})